from bot import Config, fetch_prices, backtest, print_report, write_report

if __name__ == "__main__":
    cfg = Config()
    prices = fetch_prices(cfg.watchlist, "5y")
    equity, trades = backtest(prices, cfg)
    print_report(equity, trades, cfg.starting_cash)
    write_report(equity, trades)
