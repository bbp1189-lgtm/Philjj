# Adaptive Signal Fusion — iPhone web dashboard

This project is designed to be deployed as a private or access-controlled web app, then opened in Safari on iPhone. The app is responsive and provides signal and backtest tables plus CSV downloads.

## Run locally
Python 3.11+:
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```
Open the local URL on your computer. To open from iPhone on the same Wi-Fi, configure your computer's firewall and run Streamlit with `--server.address 0.0.0.0`; this is only a local test, not a permanent hosted service.

## Deploy to Render
1. Put the project files in a private GitHub repository.
2. In Render, create a new Blueprint and connect that repository; Render reads `render.yaml`.
3. Keep the service private or add authentication before sharing its URL. Do not publish a trading dashboard with account data without access controls.
4. Add any secrets only through Render's environment settings. This app does not require Trading 212 credentials because order placement is disabled.
5. Open the resulting HTTPS URL in Safari. Use Share → Add to Home Screen to make it feel app-like.

Hosting may incur charges. Review the current plan and billing before deploying.

## Safety
- No live orders are sent by this web app.
- This is a dashboard, not a broker-certified trading system.
- External daily price data may differ from executable broker prices.
- The API starter's live-order path remains intentionally blocked pending full testing and safeguards.
