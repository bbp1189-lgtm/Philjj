import os
import streamlit as st
import pandas as pd
from bot import Config, fetch_prices, compute_signals, backtest, print_report

st.set_page_config(page_title="Adaptive Signal Fusion", page_icon="📈", layout="centered")
st.title("📈 Adaptive Signal Fusion")
st.caption("Mobile-friendly trading research dashboard · Live order placement is disabled")

st.warning(
    "Research/demo only. This dashboard does not place trades. Historical results are not forecasts. "
    "Never enter API credentials into this page; configure secrets only in your hosting provider."
)

with st.sidebar:
    st.header("Strategy settings")
    watchlist_text = st.text_input("Watchlist (comma-separated)", os.getenv("WATCHLIST", "AAPL,MSFT,NVDA,AMZN,GOOGL"))
    period = st.selectbox("History", ["2y", "5y", "10y"], index=1)
    start_cash = st.number_input("Starting cash (£)", min_value=1.0, max_value=100000.0, value=50.0, step=5.0)
    run_mode = st.selectbox("Mode", ["Signals / backtest only", "Demo account connection (not enabled here)"])
    run_button = st.button("Run analysis", type="primary", use_container_width=True)

if "analysis" not in st.session_state:
    st.session_state.analysis = None

if run_button:
    try:
        symbols = tuple(dict.fromkeys(s.strip().upper() for s in watchlist_text.split(",") if s.strip()))
        if not symbols:
            st.error("Enter at least one ticker.")
        else:
            cfg = Config()
            cfg.starting_cash = float(start_cash)
            cfg.watchlist = symbols
            with st.spinner("Downloading daily prices and calculating signals…"):
                prices = fetch_prices(symbols, period)
                latest = []
                for symbol, df in prices.items():
                    sig = compute_signals(df).dropna(subset=["score"])
                    if len(sig):
                        row = sig.iloc[-1]
                        latest.append({
                            "Ticker": symbol,
                            "Date": str(sig.index[-1].date()),
                            "Close (research feed)": round(float(row["Close"]), 2),
                            "Score": round(float(row["score"]), 3),
                            "Signal": "BUY candidate" if bool(row["buy_signal"]) else ("SELL candidate" if bool(row["sell_signal"]) else "HOLD / no trade")
                        })
                eq, trades = backtest(prices, cfg)
                st.session_state.analysis = (latest, eq, trades, start_cash)
    except Exception as exc:
        st.error(f"Analysis failed: {exc}")
        st.info("Check your internet connection, ticker symbols, and the data provider's availability.")

if st.session_state.analysis:
    latest, eq, trades, initial = st.session_state.analysis
    st.subheader("Latest signals")
    st.dataframe(pd.DataFrame(latest), use_container_width=True, hide_index=True)
    st.caption("Scores are model outputs, not probabilities of profit. Prices come from an external research data source.")
    st.subheader("Backtest")
    final = float(eq["equity"].iloc[-1])
    ret = final / initial - 1
    dd = float((eq["equity"] / eq["equity"].cummax() - 1).min())
    c1, c2, c3 = st.columns(3)
    c1.metric("Ending equity", f"£{final:,.2f}")
    c2.metric("Total return", f"{ret:.1%}")
    c3.metric("Max drawdown", f"{dd:.1%}")
    st.line_chart(eq["equity"])
    st.dataframe(eq.tail(20), use_container_width=True)
    st.subheader("Trade log")
    if trades.empty:
        st.info("No trades generated for this simulation.")
    else:
        st.dataframe(trades.tail(100), use_container_width=True, hide_index=True)
        st.download_button("Download trade log CSV", trades.to_csv(index=False), "backtest_trades.csv", "text/csv")
    st.download_button("Download equity curve CSV", eq.to_csv(), "backtest_equity.csv", "text/csv")

st.divider()
st.subheader("What this app can and cannot do")
st.markdown("""
- **Can:** calculate daily signals, run a historical simulation, and export results from your phone.
- **Cannot:** promise returns, guarantee stop-loss prices, or submit live orders.
- **Next step:** deploy this as a private web service; use demo credentials only in the hosting provider's encrypted environment settings.
""")
