"""
Adaptive Signal Fusion — educational trading bot.
Default mode is DEMO. Live order execution requires:
  1) a successful backtest report,
  2) explicit LIVE_TRADING=true,
  3) LIVE_UNLOCK=I_ACCEPT_REAL_MONEY_RISK,
  4) --execute on the command line.
This is not financial advice and does not guarantee profits.
"""
from __future__ import annotations
import argparse, base64, json, os, sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests
import yfinance as yf
from dotenv import load_dotenv

load_dotenv()
ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "state.json"
LOG_FILE = ROOT / "trades.csv"

@dataclass
class Config:
    mode: str = os.getenv("T212_ENV", "DEMO").upper()
    live_trading: bool = os.getenv("LIVE_TRADING", "false").lower() == "true"
    live_unlock: str = os.getenv("LIVE_UNLOCK", "")
    starting_cash: float = float(os.getenv("STARTING_CASH", "50"))
    risk_fraction: float = float(os.getenv("RISK_FRACTION", "0.01"))
    max_position_fraction: float = float(os.getenv("MAX_POSITION_FRACTION", "0.20"))
    max_daily_loss_fraction: float = float(os.getenv("MAX_DAILY_LOSS_FRACTION", "0.03"))
    max_drawdown_fraction: float = float(os.getenv("MAX_DRAWDOWN_FRACTION", "0.15"))
    max_positions: int = int(os.getenv("MAX_POSITIONS", "3"))
    slippage_bps: float = float(os.getenv("SLIPPAGE_BPS", "10"))
    commission_bps: float = float(os.getenv("COMMISSION_BPS", "0"))
    min_score: float = float(os.getenv("MIN_SCORE", "0.72"))
    watchlist: tuple[str, ...] = tuple(
        s.strip() for s in os.getenv("WATCHLIST", "AAPL,MSFT,NVDA,AMZN,GOOGL").split(",") if s.strip()
    )

class Trading212:
    """Small direct REST adapter using official HTTP Basic authentication."""
    def __init__(self, mode: str):
        self.mode = mode.upper()
        if self.mode not in ("DEMO", "LIVE"):
            raise ValueError("T212_ENV must be DEMO or LIVE")
        self.base = ("https://demo.trading212.com/api/v0" if self.mode == "DEMO"
                     else "https://live.trading212.com/api/v0")
        key = os.getenv("T212_API_KEY", "")
        secret = os.getenv("T212_API_SECRET", "")
        if not key or not secret:
            raise RuntimeError("Set T212_API_KEY and T212_API_SECRET in .env")
        token = base64.b64encode(f"{key}:{secret}".encode()).decode()
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Basic {token}", "Content-Type": "application/json"})

    def get(self, path: str) -> Any:
        r = self.session.get(self.base + path, timeout=20)
        r.raise_for_status()
        return r.json()

    def post(self, path: str, payload: dict) -> Any:
        r = self.session.post(self.base + path, json=payload, timeout=20)
        r.raise_for_status()
        return r.json() if r.content else {"status_code": r.status_code}

    def account_summary(self) -> Any:
        return self.get("/equity/account/summary")

    def cash(self) -> Any:
        return self.get("/equity/account/cash")

    def instruments(self) -> Any:
        return self.get("/equity/metadata/instruments")

    def positions(self) -> Any:
        return self.get("/equity/positions")

    def market_order(self, ticker: str, quantity: float) -> Any:
        # Negative quantity sells according to Trading 212's API docs.
        if quantity == 0:
            raise ValueError("Order quantity cannot be zero")
        return self.post("/equity/orders/market", {"ticker": ticker, "quantity": quantity})

def fetch_prices(symbols: tuple[str, ...], period="5y") -> dict[str, pd.DataFrame]:
    """Download adjusted daily OHLCV. External data is for research, not execution quotes."""
    data = yf.download(list(symbols), period=period, interval="1d",
                       auto_adjust=True, group_by="ticker", progress=False, threads=True)
    out = {}
    for symbol in symbols:
        try:
            df = data[symbol].copy() if isinstance(data.columns, pd.MultiIndex) else data.copy()
            df = df.rename(columns=str.title)
            needed = ["Open", "High", "Low", "Close", "Volume"]
            df = df[[c for c in needed if c in df.columns]].dropna()
            if "Close" in df and len(df) >= 220:
                out[symbol] = df
        except (KeyError, TypeError):
            continue
    if not out:
        raise RuntimeError("No usable price history returned; check symbols/network.")
    return out

def compute_signals(df: pd.DataFrame) -> pd.DataFrame:
    """Daily signal fusion: trend + relative momentum + volume + volatility regime."""
    x = df.copy()
    close, volume = x["Close"], x["Volume"]
    x["sma50"] = close.rolling(50).mean()
    x["sma200"] = close.rolling(200).mean()
    x["mom63"] = close.pct_change(63)
    x["mom126"] = close.pct_change(126)
    x["vol20"] = close.pct_change().rolling(20).std() * np.sqrt(252)
    x["vol_med20"] = volume.rolling(20).median()
    x["vol_ratio"] = volume / x["vol_med20"].replace(0, np.nan)

    # Continuous scores avoid a single indicator deciding everything.
    trend = ((close > x["sma200"]).astype(float) + (x["sma50"] > x["sma200"]).astype(float)) / 2
    momentum = (x["mom63"].rank(pct=True) * 0.5 + x["mom126"].rank(pct=True) * 0.5)
    # For each asset separately, rank is a time-series percentile, not cross-asset rank.
    momentum = x["mom63"].rolling(252, min_periods=100).apply(
        lambda a: pd.Series(a).rank(pct=True).iloc[-1], raw=False
    ) * 0.5 + x["mom126"].rolling(252, min_periods=100).apply(
        lambda a: pd.Series(a).rank(pct=True).iloc[-1], raw=False
    ) * 0.5
    volume_score = (x["vol_ratio"].clip(0, 2) / 2).fillna(0.5)
    # Prefer tradable middle-volatility conditions; penalise extreme volatility.
    vol_score = (1 - ((x["vol20"] - 0.25).abs() / 0.75)).clip(0, 1)
    x["score"] = 0.40 * trend + 0.30 * momentum + 0.15 * volume_score + 0.15 * vol_score
    x["buy_signal"] = (x["score"] >= float(os.getenv("MIN_SCORE", "0.72"))) & (close > x["sma50"]) & (close > x["sma200"])
    x["sell_signal"] = (close < x["sma50"]) | (x["score"] < 0.40)
    return x

def backtest(prices: dict[str, pd.DataFrame], cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Long-only daily close-to-next-close simulation with costs and risk brakes."""
    symbols = list(prices)
    signals = {s: compute_signals(df) for s, df in prices.items()}
    dates = sorted(set.intersection(*(set(df.index) for df in signals.values())))
    if len(dates) < 220:
        raise RuntimeError("Not enough overlapping daily history for backtest.")
    cash = cfg.starting_cash
    qty: dict[str, float] = {}
    entry: dict[str, float] = {}
    equity_rows, trades = [], []
    peak = cash
    halted = False
    previous_equity = cash
    for i in range(201, len(dates)-1):
        day, next_day = dates[i], dates[i+1]
        # Mark to market at today's close.
        marks = {s: float(signals[s].loc[day, "Close"]) for s in symbols}
        equity = cash + sum(qty.get(s, 0) * marks[s] for s in symbols)
        peak = max(peak, equity)
        drawdown = 1 - equity / peak if peak else 0
        if drawdown >= cfg.max_drawdown_fraction:
            halted = True
        daily_loss = (equity / previous_equity - 1) if previous_equity > 0 else 0.0
        daily_loss_halt = daily_loss <= -cfg.max_daily_loss_fraction
        # Sell first. Signals are known at close, execution assumed next close.
        for s in list(qty):
            row = signals[s].loc[day]
            if halted or bool(row["sell_signal"]):
                px = float(signals[s].loc[next_day, "Open"] if "Open" in signals[s] else signals[s].loc[next_day, "Close"])
                px *= (1 - cfg.slippage_bps / 10000)
                gross = qty[s] * px
                fee = gross * cfg.commission_bps / 10000
                cash += gross - fee
                pnl = (px - entry[s]) * qty[s] - fee
                trades.append({"date": next_day, "symbol": s, "side": "SELL", "quantity": qty[s],
                               "price": px, "pnl_estimate": pnl, "reason": "risk_halt" if halted else "signal"})
                del qty[s], entry[s]
        if not halted and not daily_loss_halt:
            # Buy at next day's open; position size uses a stop-distance proxy of 2x daily volatility.
            candidates = []
            for s in symbols:
                row = signals[s].loc[day]
                if s not in qty and bool(row["buy_signal"]) and np.isfinite(row["vol20"]) and row["vol20"] > 0:
                    candidates.append((float(row["score"]), s, row))
            for score, s, row in sorted(candidates, reverse=True)[:max(0, cfg.max_positions-len(qty))]:
                px = float(signals[s].loc[next_day, "Open"] if "Open" in signals[s] else signals[s].loc[next_day, "Close"])
                px *= (1 + cfg.slippage_bps / 10000)
                equity = cash + sum(qty.get(k, 0) * float(signals[k].loc[day, "Close"]) for k in qty)
                risk_cash = max(0, equity * cfg.risk_fraction)
                stop_distance = px * min(0.25, max(0.03, 2 * float(row["vol20"]) / np.sqrt(252)))
                budget = min(cash, equity * cfg.max_position_fraction, risk_cash / (stop_distance / px))
                # Avoid tiny orders and prohibit leverage.
                budget = min(budget, cash / (1 + cfg.commission_bps / 10000))
                q = budget / px if px > 0 else 0
                if q <= 0 or budget < 1:
                    continue
                fee = budget * cfg.commission_bps / 10000
                cash -= budget + fee
                qty[s], entry[s] = q, px
                trades.append({"date": next_day, "symbol": s, "side": "BUY", "quantity": q,
                               "price": px, "pnl_estimate": 0.0, "reason": f"score={score:.3f}"})
        equity_rows.append({"date": day, "equity": equity, "cash": cash, "positions": len(qty),
                            "drawdown": drawdown, "daily_loss": daily_loss,
                            "daily_loss_halt": daily_loss_halt, "halted": halted})
        previous_equity = equity
    # Liquidate remaining holdings at last available close for final equity estimate.
    last = dates[-1]
    final_equity = cash + sum(qty.get(s, 0) * float(signals[s].loc[last, "Close"]) for s in qty)
    equity_rows.append({"date": last, "equity": final_equity, "cash": cash, "positions": len(qty),
                        "drawdown": 0.0, "halted": halted})
    eq = pd.DataFrame(equity_rows).drop_duplicates("date").set_index("date")
    tr = pd.DataFrame(trades)
    return eq, tr

def print_report(eq: pd.DataFrame, trades: pd.DataFrame, start_cash: float):
    final = float(eq["equity"].iloc[-1])
    total_return = final / start_cash - 1
    daily = eq["equity"].pct_change().dropna()
    sharpe = (daily.mean() / daily.std() * np.sqrt(252)) if daily.std() else 0.0
    max_dd = float((eq["equity"] / eq["equity"].cummax() - 1).min())
    sells = trades[trades["side"] == "SELL"] if not trades.empty else pd.DataFrame()
    wins = float((sells["pnl_estimate"] > 0).mean()) if len(sells) else float("nan")
    print("\n=== BACKTEST REPORT (historical simulation, not a forecast) ===")
    print(f"Starting cash: £{start_cash:.2f}")
    print(f"Final estimated equity: £{final:.2f}")
    print(f"Total return: {total_return:.1%}")
    print(f"Max drawdown: {max_dd:.1%}")
    print(f"Annualised Sharpe (rough): {sharpe:.2f}")
    print(f"Closed-trade win fraction: {wins:.1%}" if len(sells) else "Closed-trade win fraction: n/a")
    print(f"Trades recorded: {len(trades)}")
    print("Caveats: survivorship bias, price-feed differences, tax, spreads, fills and corporate actions can affect results.")

def write_report(eq: pd.DataFrame, trades: pd.DataFrame):
    eq.to_csv(ROOT / "backtest_equity.csv")
    trades.to_csv(ROOT / "backtest_trades.csv", index=False)
    print(f"Saved {ROOT / 'backtest_equity.csv'} and {ROOT / 'backtest_trades.csv'}")

def live_guard(cfg: Config, execute: bool):
    if cfg.mode == "LIVE":
        if not cfg.live_trading or cfg.live_unlock != "I_ACCEPT_REAL_MONEY_RISK" or not execute:
            raise RuntimeError(
                "LIVE ORDER BLOCKED. Require LIVE_TRADING=true, "
                "LIVE_UNLOCK=I_ACCEPT_REAL_MONEY_RISK and --execute."
            )
    elif execute:
        print("DEMO mode selected: orders, if enabled, go to the demo environment.")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--backtest", action="store_true", help="Run historical simulation only")
    p.add_argument("--signals", action="store_true", help="Print latest signals; no orders")
    p.add_argument("--account", action="store_true", help="Read Trading 212 account summary")
    p.add_argument("--execute", action="store_true", help="Allow orders only if all safety gates pass")
    p.add_argument("--period", default="5y")
    args = p.parse_args()
    cfg = Config()
    if args.backtest:
        prices = fetch_prices(cfg.watchlist, args.period)
        eq, trades = backtest(prices, cfg)
        print_report(eq, trades, cfg.starting_cash)
        write_report(eq, trades)
        return
    if args.account:
        api = Trading212(cfg.mode)
        print(json.dumps(api.account_summary(), indent=2))
        return
    prices = fetch_prices(cfg.watchlist, "2y")
    latest = []
    for symbol, df in prices.items():
        sig = compute_signals(df).dropna(subset=["score"])
        if len(sig):
            row = sig.iloc[-1]
            latest.append({"symbol": symbol, "date": str(sig.index[-1].date()),
                           "close": float(row["Close"]), "score": float(row["score"]),
                           "buy": bool(row["buy_signal"]), "sell": bool(row["sell_signal"])})
    print(json.dumps(latest, indent=2))
    if args.signals or not args.execute:
        print("\nNo orders sent. Use --execute only after demo testing and review.")
        return
    live_guard(cfg, args.execute)
    api = Trading212(cfg.mode)
    # Intentionally do not auto-submit portfolio orders in this starter.
    # Price-feed tickers (e.g. AAPL) are not guaranteed to match T212 instrument tickers.
    # Confirm ticker mappings, holdings, market hours, and minimum order sizes before enabling.
    raise RuntimeError(
        "Order execution intentionally disabled in this starter. Implement and test an explicit "
        "ticker mapping, holdings reconciliation, duplicate-order prevention, and order-size checks "
        "against the current official API before placing real orders."
    )

if __name__ == "__main__":
    main()
